@extends('layout.app')

@section('content')
    <div class="container mx-auto px-4">
        <section class="body-font">
            <div class="container px-5 py-10 mx-auto">
                <div class="flex flex-col text-center w-full mb-10">
                    <h1
                        class="sm:text-3xl text-2xl font-medium title-font mb-4 text-white">
                        uwu
                    </h1>
                    <p class="lg:w-2/3 mx-auto leading-relaxed text-white">
                        xdddd
                    </p>
                </div>
                <div class="flex flex-col text-center w-full mb-4">
                    <h1 class="sm:text-3xl text-2xl font-medium title-font mb-4 text-gray-100">
                        Datos del Proyecto
                    </h1>
                </div>
            </div>
        </section>
    </div>
@endsection

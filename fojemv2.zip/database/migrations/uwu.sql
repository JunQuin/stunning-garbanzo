DB::statement("ALTER TABLE users MODIFY asesor int");
